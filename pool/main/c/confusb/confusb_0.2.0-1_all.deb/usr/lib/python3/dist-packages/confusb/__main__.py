# SPDX-License-Identifier: GPL-3.0-or-later
from .app import cli

cli()
